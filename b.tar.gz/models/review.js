module.exports = function(sequelize, DataTypes) {
  var Review = sequelize.define("Review", {
    title: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        len: [1]
      }
    },
    body: {
      type: DataTypes.TEXT,
      allowNull: false,
      len: [1]
    }
    }
    // configuration, {
    //   associate: function(models) {
    //     Review.belongsTo(models.user, {
    //       foreignKey:{
    //         allowNull: false
    //       }
    //     });
    //   }
    // }
  // Add another "configuration" obect as an argument to set up an association to Authors
  // Example: http://docs.sequelizejs.com/en/1.7.0/articles/express/#modelstaskjs
  );
  return Review;
};
